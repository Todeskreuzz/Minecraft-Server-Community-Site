@echo off
powershell.exe -NoProfile -File "%~dp0Install-FriendsAndFoes.ps1"
pause
