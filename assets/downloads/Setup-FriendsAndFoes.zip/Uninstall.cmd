@echo off
"%LOCALAPPDATA%\FriendsAndFoes\FriendsAndFoes.exe" --uninstall
